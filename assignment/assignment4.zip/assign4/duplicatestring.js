let str="this is javascript programming place"
let newstr=""
for (i=0;i<str.length;i++)
    {
if(newstr.indexOf(str[i])===-1)
{
    newstr+=str[i]
}
    }
    console.log(newstr)

    
   